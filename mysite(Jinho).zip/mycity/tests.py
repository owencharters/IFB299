from django.contrib.auth.models import User
from django.test import TestCase


class LogInTest(TestCase):
    def setUp(self):
        self.credentials = {
            'username': 'testuser',
            'password': 'secret'}
        User.objects.create_user(**self.credentials)

    # send correct login data
    def test_login1(self):
        login = self.client.login(username='testuser', password='secret')
        self.assertTrue(login == True)

    # send wrong login data
    def test_login2(self):
        login = self.client.login(username='testuser', password='1234')
        self.assertTrue(login == False)


