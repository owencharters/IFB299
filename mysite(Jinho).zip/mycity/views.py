from django.shortcuts import redirect, render
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.template import loader
from .models import UserType
from .forms import UserForm


def index(request):
    return render(request, 'index.html')


def register(request):
    template = loader.get_template('register.html')
    user_type_all = UserType.objects.order_by('-type_desc')
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return HttpResponseRedirect('/index/')
    else:
        form = UserForm()

    return render(request, 'register.html', {'form': form})