from django.apps import AppConfig


class MycityConfig(AppConfig):
    name = 'mycity'
