from django.test import TestCase
from .models import User
from .models import UserType
from .models import Weather
# Test if username is over 20 characters.
class User(TestCase):

    def test(self):
        type1 = 'jwlfjlwkjflkwejfklwjfwlkfjflkwjeflewkfjewlkfjweflkwejfwelkfjwelfkjfklfjwelkfj';
        test_question = User(username=type1)

        self.assertIs(test_question.__str__(), False)

# Test if lastName is over 20 characters.
class User(TestCase):

    def test(self):
        type2 = 'jfewklfjcjsklejijdfkleijslkdjfeisjfkeljfeiljslkfdfe';
        test_question = User(user_lastname=type2)

        self.assertIs(test_question.__str__(), False)

# Test if usertype does not have any characters.
class UserType(TestCase):

    def test(self):
        type3 = '';
        test_question = UserType(type_desc=type3)

        self.assertIs(test_question.__str__(), False)
