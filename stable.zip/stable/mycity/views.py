from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.template import loader
from .models import Cities
from .models import UserType
from .models import User
from .forms import *
from django.core.urlresolvers import reverse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.conf import settings



@login_required
def index(request):
    cities_all = Cities.objects.order_by('-title')[:5]
    template = loader.get_template('index.html')
    return render(request, 'index.html')


def register(request):
    template = loader.get_template('register.html')
    user_type_all = UserType.objects.order_by('-type_desc')
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return HttpResponseRedirect('/index/')
    else:
        form = UserForm()

    return render(request, 'register.html', {'form': form})

def summary(request, button_id):
    template = loader.get_template('summary.html')
    if button_id == "hotels":
        test = "hotels"
    elif button_id == "city_information":
        test = "city_information"
    elif button_id == "transport":
        test = "transport"
    elif button_id == "other_cities":
        test = "other_cities"
    elif button_id == "weather":
        test = "weather"
    elif button_id == "medical_services":
        test = "medical_services"
    elif button_id == "travel_services":
        test = "travel_services"
    else:
        test = "Can be used to list information about city information"
    return render(request, 'summary.html', {'test':test})

def profile(request):
    template = loader.get_template('profile.html')
    return render(request, 'profile.html')


def model_form_upload(request):
	if request.method == 'POST':
		form = DocumentForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			messages.add_message(request, messages.SUCCESS, 'File Uploaded Successfully')
	else:
		form = DocumentForm()
	return render(request, 'model_form_upload.html', {
		'form': form
		})

def administratorPage(request):
    cities_all = Cities.objects.order_by('-title')[:5]
    template = loader.get_template('administratorPage.html')
    return render(request, 'administratorPage.html')

def login(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('home')
    else:
        form = UserForm()
    return render(request, 'login.html', {'form': form})
